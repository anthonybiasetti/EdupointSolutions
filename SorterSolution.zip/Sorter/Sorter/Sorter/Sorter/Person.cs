﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Sorter
{
    class Person
    {
        public string firstName { get; set; }
        public string lastName { get; set; }

        public Person()
        {

        }
        public Person(string lastName)
        {
            this.lastName = lastName;
        }
        public Person(string firstName, string lastName)
        {
            this.firstName = firstName;
            this.lastName = lastName;
        }

        public override string ToString()
        {
            if(firstName==null)
            {
                return lastName;
            }
            else
            return lastName + ", " + firstName;
        }
    }
}
